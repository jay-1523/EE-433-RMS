/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package RMS.WaitstaffClient;

/**
 *
 * @author zgriffin
 */
public class Order extends RMS.Base.Order {
    
    private String drink = "";
    private String entree = "";
    private String side = "";
    private String dessert = "";
    // enum for an OrderStatus
    
    // what is required to construct an Order


    /**
     * @return the drink
     */
    public String getDrink() {
        return drink;
    }

    /**
     * @param drink the drink to set
     */
    public void setDrink(String drink) {
        this.drink = drink;
    }

    /**
     * @return the entree
     */
    public String getEntree() {
        return entree;
    }

    /**
     * @param entree the entree to set
     */
    public void setEntree(String entree) {
        this.entree = entree;
    }

    /**
     * @return the side
     */
    public String getSide() {
        return side;
    }

    /**
     * @param side the side to set
     */
    public void setSide(String side) {
        this.side = side;
    }

    /**
     * @return the dessert
     */
    public String getDessert() {
        return dessert;
    }

    /**
     * @param dessert the dessert to set
     */
    public void setDessert(String dessert) {
        this.dessert = dessert;
    }

}
