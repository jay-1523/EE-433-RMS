package EE433;

public class Employee {

    private String EmployeeID;
    private String firstName;
    private String lastName;
    private int hours;
    private String hireDate;

    private EE433.Employee.Status status;
    
    //--------------------------------------
    public String ToSQLInsert(){
        String results = "";
        
        // results - build your sql statement
        
        return(results);
    }
    
    public String ToSQLUodate(){
        String results = "";
        
        return(results);
        
    }
    // importers
    public static Employee FromSQL(String employeeID){
        
        
        
        return(null);
        
    }
    
   // public static Employee FromSQL(all the inputs){
//}
    
//    public static Employee FromSQL(java.util.Vector<java.util.Vector<Object>> data){
//    }
//    
//    public static Employee FromWaitClient(String text){
//        // parse the text from the client base on a colon
//}
    
    public String ToWaitClient(){
        String results = "";
        
     //   results += "EmployeeID" + this.EmployeeID  + '/n'
        
        return(results);
    }
    
    // consider an oveerload that would tell you which client to send it to... public String ToXClient(){}
    
    //--------------------------------------

    enum Status {
        active, off;
    }

    // makes list of employees
    private static java.util.ArrayList<EE433.Employee> Employees = new java.util.ArrayList<EE433.Employee>();

    public static int getCount() {
        return (Employees.size());
    }

    public static java.util.ArrayList<EE433.Employee> getEmployees() {
        return (Employees);
    }

    // Constructors ---------------------------------
    public Employee() {
       // this.status = EE433.Employee.Status.off;
        this.EmployeeID = "";
        this.firstName = "";
        this.lastName = "";
        this.hours = 0;
        this.hireDate = "";
        this.status = status;
        EE433.Employee.Employees.add(this);
    }
    
    public Employee(String firstName, String lastName) {

        this.EmployeeID = "";
        this.firstName = firstName;
        this.lastName = lastName;
        this.hours = 0;
        this.hireDate = "";
        this.status = status;
        EE433.Employee.Employees.add(this);
    }
    
     public Employee(String EmployeeID, String firstName, String lastName) {

        this.EmployeeID = EmployeeID;
        this.firstName = firstName;
        this.lastName = lastName;
        this.hours = 0;
        this.hireDate = "";
        this.status = status;
        EE433.Employee.Employees.add(this);
    }

    public Employee(String EmployeeID, String firstName, String lastName, int hours, String hireDate, EE433.Employee.Status status) {

        this.EmployeeID = EmployeeID;
        this.firstName = firstName;
        this.lastName = lastName;
        this.hours = hours;
        this.hireDate = hireDate;
        this.status = status;
        Employees.add(this);
    }
    // ----------------------------------------------------
    
    
    

//    public Employee(String firstName, String lastName) {
//
//        this.status = EE433.Employee.Status.off;
//        String ID;
//        int index = 0;
//
//        if ((firstName == null) || (firstName.length() == 0)) {
//            this.status = EE433.Employee.Status.off;
//            this.EmployeeID = "";
//            this.firstName = "";
//            this.lastName = "";
//        } else if ((lastName == null) || (lastName.length() == 0)) {
//            this.status = EE433.Employee.Status.off;
//            this.EmployeeID = "";
//            this.firstName = "";
//            this.lastName = "";
//        } else {
//
//            ID = firstName.charAt(0) + lastName + java.lang.Integer.toString(index);
//            while (EE433.Employee.verifyID(ID) == true) {
//                index++;
//                ID = firstName.charAt(0) + lastName + java.lang.Integer.toString(index);
//            }
//            this.status = EE433.Employee.Status.active;
//            this.EmployeeID = ID;
//            this.firstName = firstName;
//            this.lastName = lastName;
//        }
//
//    }

   

    // called to create ID
    private static boolean verifyID(String ID) {
        boolean results = false;
        int index = 0;

        while ((index < Employees.size()) && (results == false)) {
            if (Employees.get(index).getEmployeeID().compareToIgnoreCase(ID) == 0) {
                results = true;
            } else {
                index++;
            }
        }
        return (results);
    }


//    public static Employee importCustom(String customString) {
//
//        Employee tempEmployee;
//        String ID = "";
//        String firstName = "";
//        String lastName = "";
//        Status status = EE333.Status.unknown;
//        EE333.ContactInfo contactInfo;
//        String[] lines;
//        String[] chunks;
//
//        lines = customString.split("\n");
//        for (int index = 0; index < lines.length; index++) {
//            chunks = lines[index].split(": ");
//            if (chunks.length == 2) {
//                if (chunks[0].compareToIgnoreCase("ID") == 0) {
//                    ID = chunks[1];
//                } else if (chunks[0].compareToIgnoreCase("firstName") == 0) {
//                    firstName = chunks[1];
//                } else if (chunks[0].compareToIgnoreCase("lastName") == 0) {
//                    lastName = chunks[1];
//                } else if (chunks[0].compareToIgnoreCase("status") == 0) {
//                    try {
//                        status = EE333.Status.valueOf(chunks[1]);
//                    } catch (java.lang.IllegalArgumentException ex) {
//                        status = EE333.Status.unknown;
//                    }
//                } else {
//                }
//            } else {
//            }
//        }
//
//        contactInfo = EE333.ContactInfo.importUserCustom(customString);
//
//        if ((ID.length() > 0) && (firstName.length() > 0) && (lastName.length() > 0)) {
//            tempEmployee = new Employee(ID, firstName, lastName);
//            tempEmployee.getContactInfo();
//        } else if ((firstName.length() > 0) && (lastName.length() > 0)) {
//            tempEmployee = new Employee(firstName, lastName);
//            tempEmployee.getContactInfo();
//        } else {
//            tempEmployee = new Employee();
//        }
//
//        return (tempEmployee);
//    }
//
//    public static String exportCustomAll() {
//        String results = "";
//        java.io.File outputFile;
//        java.io.FileWriter outputFileWriter;
//        int index;
//
//        try {
//            for (index = 0; index < Employees.size(); index++) {
//                outputFile = new java.io.File(Employees.get(index).ID + ".txt");
//                outputFileWriter = new java.io.FileWriter(outputFile, false);
//                outputFileWriter.append(Employees.get(index).toCustom());
//                outputFileWriter.close();
//
//                results += Employees.get(index).toCustom();
//            }
//        } catch (Exception ex) {
//            System.out.println(ex.toString());
//        }
//
//        return (results);
//    }
//    
//
//    public static Employee importCSV(String CSVString) {
//        EE333.Employee tempEmployee = new EE333.Employee();
//
//        tempEmployee.fromCSV(CSVString);
//
//        return (tempEmployee);
//
//    }
//
//    public static String exportCSVAll() {
//        String results = "";
//        java.io.File outputFile;
//        java.io.FileWriter outputFileWriter;
//        int index;
//
//        try {
//            for (index = 0; index < Employees.size(); index++) {
//                outputFile = new java.io.File(Employees.get(index).ID + ".csv");
//                outputFileWriter = new java.io.FileWriter(outputFile, false);
//                outputFileWriter.append(Employees.get(index).toCSV());
//                outputFileWriter.close();
//
//                results += Employees.get(index).toCSV();
//            }
//        } catch (Exception ex) {
//            System.out.println(ex.toString());
//        }
//
//        return (results);
//    }
//
//    
//    
//    
//    @Override
//    public String toCustomFile(){
//        java.io.File outputFile;
//        java.io.FileWriter outputFileWriter;
//        String results;
//
//        results = "";
//
//        try {
//            outputFile = new java.io.File(this.ID + ".txt");
//            outputFileWriter = new java.io.FileWriter(outputFile);
//            outputFileWriter.append(this.toCustom());
//            outputFileWriter.close();
//            results = toCustom();
//        } catch (Exception ex) {
//            System.out.println(ex.toString());
//        }
//
//        return (results);
//    }
//    
//    @Override
//    public Employee fromCustom(String contents) {
//        // DO CODE TO PARSE FILE
//
//        java.io.File inputFile;
//        java.io.FileReader inputFileReader;
//        java.io.BufferedReader inputBufferedReader;
//        String output = "";
//
//        EE333.Employee tempEmployee = new EE333.Employee(); // may not need to see this
//        String ID = "";
//        String firstName = "";
//        String lastName = "";
//        EE333.ContactInfo contactInfo;
//        EE333.Status status;
//
//        try {
//            inputFile = new java.io.File(contents);
//            if (inputFile.exists() == true) {
//                inputFileReader = new java.io.FileReader(inputFile);
//                inputBufferedReader = new java.io.BufferedReader(inputFileReader);
//
//                String[] lines;
//                String[] chunks;
//
//                lines = contents.split("\n");
//                for (int index = 0; index < lines.length; index++) {
//                    chunks = lines[index].split(": ");
//                    if (chunks.length == 2) {
//                        if (chunks[0].compareToIgnoreCase("ID") == 0) {
//                            ID = chunks[1];
//                        } else if (chunks[0].compareToIgnoreCase("firstName") == 0) {
//                            firstName = chunks[1];
//                        } else if (chunks[0].compareToIgnoreCase("lastName") == 0) {
//                            lastName = chunks[1];
//                        } else if (chunks[0].compareToIgnoreCase("status") == 0) {
//                            try {
//                                status = EE333.Status.valueOf(chunks[1]);
//                            } catch (java.lang.IllegalArgumentException ex) {
//                                status = EE333.Status.unknown;
//                            }
//                        } else {
//                        }
//                    } else {
//                    }
//                }
//
//                inputBufferedReader.close();
//                inputFileReader.close();
//            } else {
//
//            }
//        } catch (java.lang.Exception ex) {
//            System.out.println(ex.toString());
//        }
//
//        if ((ID.length() > 0) && (firstName.length() > 0) && (lastName.length() > 0)) {
//            tempEmployee = new Employee(ID, firstName, lastName);
//        } else if ((firstName.length() > 0) && (lastName.length() > 0)) {
//            tempEmployee = new Employee(firstName, lastName);
//        } else {
//            tempEmployee = new Employee();
//        }
//
//        return (tempEmployee);
//        //    throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
//
//    }
//    
//    
//    public String toCSVFile() {
//        java.io.File outputFile;
//        java.io.FileWriter outputFileWriter;
//        String results;
//
//        results = "";
//
//        try {
//            outputFile = new java.io.File(this.ID + ".txt");
//            outputFileWriter = new java.io.FileWriter(outputFile);
//            outputFileWriter.append(this.toCSV());
//            outputFileWriter.close();
//            results = toCSV();
//        } catch (Exception ex) {
//            System.out.println(ex.toString());
//        }
//
//        return (results);
//
//        //  throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
//    }
//        
//    @Override
//    public Employee fromCSV(String contents) {
//
//        java.io.File inputFile;
//        java.io.FileReader inputFileReader;
//        java.io.BufferedReader inputBufferedReader;
//        String output = "";
//
//        String line;
//        String[] chunks;
//
//        EE333.Employee tempEmployee = new EE333.Employee(); // may not need to see this
//        String ID;
//        String firstName;
//        String lastName;
//        EE333.ContactInfo contactInfo;
//        EE333.Status status;
//
//        try {
//            inputFile = new java.io.File(contents);
//            if (inputFile.exists() == true) {
//                inputFileReader = new java.io.FileReader(inputFile);
//                inputBufferedReader = new java.io.BufferedReader(inputFileReader);
//
//                while ((line = inputBufferedReader.readLine()) != null) {
//                    output += line + '\n';
//                    chunks = line.split(",");
//                    if (chunks.length == 5) {
//
//                        ID = chunks[0];
//                        firstName = chunks[1];
//                        lastName = chunks[2];
//                        try {
//                            status = EE333.Status.valueOf(chunks[3]);
//                        } catch (java.lang.Exception parseEx) {
//                            System.out.println(parseEx.toString());
//                            status = EE333.Status.unknown;
//                        }
//
//                        contactInfo = EE333.ContactInfo.importUserCustom(output); // change to CSV and make method
//
//                        tempEmployee = new EE333.Employee(ID, firstName, lastName, contactInfo, status);
//                        tempEmployee.setStatus(status);
//
//                    } else {
//                        output = "";
//                    }
//                }
//                inputBufferedReader.close();
//                inputFileReader.close();
//            } else {
//
//            }
//        } catch (java.lang.Exception ex) {
//            System.out.println(ex.toString());
//        }
//        return (tempEmployee);
//        //    throw new UnsupportedOperationException("Not supported yet."); 
//
//    }
//
//    
    public EE433.Employee.Status getStatus() {
        return status;
    }

    public void setStatus(EE433.Employee.Status status) {
        this.status = status;
    }

   
    public String getEmployeeID() {
        return EmployeeID;
    }

  
    public void setEmployeeID(String EmployeeID) {
        this.EmployeeID = EmployeeID;
    }

 
    public String getFirstName() {
        return firstName;
    }

   
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

  
    public String getLastName() {
        return lastName;
    }

    
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    
    public int getHours() {
        return hours;
    }

    
    public void setHours(int hours) {
        this.hours = hours;
    }

   
    public String getHireDate() {
        return hireDate;
    }

    
    public void setHireDate(String hireDate) {
        this.hireDate = hireDate;
    }

    /**
     * @param aEmployees the Employees to set
     */
    public static void setEmployees(java.util.ArrayList<EE433.Employee> aEmployees) {
        Employees = aEmployees;
    }

}
