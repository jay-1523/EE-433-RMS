

/**
 *
 * @author roman
 */
public class Delivery {
    
    private static java.util.ArrayList<Delivery> Deliverys = new java.util.ArrayList<Delivery>(); 
    
    private String name;
    private String delivery_order;
    
    public Delivery() { 
        
        this.name = ""; 
        this.delivery_order = ""; 
        
    }
    
    public static Delivery importInfoXML( String xmlString ) {
        Delivery tempDelivery = null; 
        String name = ""; 
        String delivery_order = ""; 
        String[] lines;
        String[] chunks;
        
        lines = xmlString.split("\n");
        for (int index = 0; index < lines.length; index++) {
            chunks = lines[index].split(": ");
            if (chunks.length == 2) {
                if (chunks[0].compareToIgnoreCase("name") == 0) {
                    name = chunks[1];
                } else if (chunks[0].compareToIgnoreCase("delivery order") == 0) {
                    delivery_order = chunks[1];
                } else {
                    // we ignore it...
                }
            } else {
                // we ignore it..
            }
        }
        
        tempDelivery.setName(name);
        tempDelivery.setDelivery_order(delivery_order);
        
        return( tempDelivery ); 
    } 

 
    
    public String exportInfoXML() {
        String output = "";
       
       output += "<?xml version=\"1.0\" encoding=\"UTF-8\"?>" + '\n';
       output += "<Delivery>" + '\n';
       output += '\t' + "<name>" + this.getName() + "</name>" + '\n';
       output += '\t' + "<delivery order>" + this.getDelivery_order() + "</delivery order>" + '\n';
       
       output += "<Delivery>" + '\n';
        
        return( output ); 
    }
    
    public boolean DeliveryCopy( Delivery delivery ) {
        
        return( true );
    }

    /**
     * @return the Deliverys
     */
    public static java.util.ArrayList<Delivery> getDeliverys() {
        return Deliverys;
    }

    /**
     * @param aDeliverys the Deliverys to set
     */
    public static void setDeliverys(java.util.ArrayList<Delivery> aDeliverys) {
        Deliverys = aDeliverys;
    }


    /**
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**
     * @param name the name to set
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * @return the delivery_order
     */
    public String getDelivery_order() {
        return delivery_order;
    }

    /**
     * @param delivery_order the delivery_order to set
     */
    public void setDelivery_order(String delivery_order) {
        this.delivery_order = delivery_order;
    }
    
}
