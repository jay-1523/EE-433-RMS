
package EE433;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import java.sql.PreparedStatement;




public class AddRemoveEmployeeJFrame extends javax.swing.JFrame {

    // Reading table---------------------
    private javax.swing.table.DefaultTableModel buildTableModel(java.sql.ResultSet resultset)
            throws java.sql.SQLException {

        java.sql.ResultSetMetaData resultsetmetaData = resultset.getMetaData();
        java.util.Vector<String> columnNames = new java.util.Vector<String>();
        java.util.Vector<java.util.Vector<Object>> data = new java.util.Vector<java.util.Vector<Object>>();
        
        // names of columns        
        int columnCount = resultsetmetaData.getColumnCount();
        for (int columnindex = 1; columnindex <= columnCount; columnindex++) {
            columnNames.add(resultsetmetaData.getColumnName(columnindex));
        }

        // data of the table
        resultset.beforeFirst();
        while (resultset.next() == true) {
            java.util.Vector<Object> vector = new java.util.Vector<Object>();
            for (int columnindex = 1; columnindex <= columnCount; columnindex++) {
                vector.add(resultset.getObject(columnindex));
            }
            data.add(vector);
        }

        return new javax.swing.table.DefaultTableModel(data, columnNames);
    }
    
    //---------------------------------------------------------------
    
    


////        this.jTextFieldcourseID.setText(inputRegistration.getCourseID());
////        this.jTextFieldsection.setText(inputRegistration.getSection());
////        this.jTextFieldterm.setText(inputRegistration.getTerm());
////        this.jTextFieldCRN.setText(String.valueOf(inputRegistration.getCRN()));
////        this.jTextFieldsignupDate.setText(inputRegistration.getSignupDate());
////        this.jTextFieldblazerID.setText(inputRegistration.getBlazerID());

    
    public AddRemoveEmployeeJFrame() {
        initComponents();
    }

   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        jPanel1 = new javax.swing.JPanel();
        jButtonApply = new javax.swing.JButton();
        jButtonBack = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        jRadioButtonAdd = new javax.swing.JRadioButton();
        jRadioButtonRemove = new javax.swing.JRadioButton();
        jTextFieldEmployeeID = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jTextFieldFirstName = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jTextFieldLastName = new javax.swing.JTextField();
        jTextFieldDate = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        jButtonApply.setText("Apply");
        jButtonApply.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonApplyActionPerformed(evt);
            }
        });

        jButtonBack.setText("Back to Main");
        jButtonBack.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonBackActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(42, 42, 42)
                .addComponent(jButtonApply)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 78, Short.MAX_VALUE)
                .addComponent(jButtonBack)
                .addGap(25, 25, 25))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButtonApply)
                    .addComponent(jButtonBack))
                .addContainerGap(33, Short.MAX_VALUE))
        );

        jPanel2.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        buttonGroup1.add(jRadioButtonAdd);
        jRadioButtonAdd.setText("Add");
        jRadioButtonAdd.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                jRadioButtonAddStateChanged(evt);
            }
        });
        jRadioButtonAdd.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jRadioButtonAddActionPerformed(evt);
            }
        });

        buttonGroup1.add(jRadioButtonRemove);
        jRadioButtonRemove.setText("Remove");

        jLabel1.setText("Employee ID:");

        jTextFieldFirstName.setText("Zeb");

        jLabel2.setText("First Name:");

        jLabel3.setText("Last Name:");

        jLabel4.setText("Date:");

        jTextFieldLastName.setText("Griffin");

        jTextFieldDate.setText("2021-12-9 10:20:00");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel1)
                            .addComponent(jLabel2)
                            .addComponent(jLabel3)
                            .addComponent(jLabel4))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jTextFieldFirstName)
                            .addComponent(jTextFieldEmployeeID, javax.swing.GroupLayout.DEFAULT_SIZE, 203, Short.MAX_VALUE)
                            .addComponent(jTextFieldLastName)
                            .addComponent(jTextFieldDate)))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(83, 83, 83)
                        .addComponent(jRadioButtonAdd)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jRadioButtonRemove)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(29, 29, 29)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jRadioButtonAdd)
                    .addComponent(jRadioButtonRemove))
                .addGap(10, 10, 10)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1)
                    .addComponent(jTextFieldEmployeeID, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jTextFieldFirstName, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jTextFieldLastName, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3))
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jTextFieldDate, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel4))
                .addContainerGap(38, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButtonBackActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonBackActionPerformed
        EE433.ManagerStartJFrame popupManagerStartJFrame = new EE433.ManagerStartJFrame();
        popupManagerStartJFrame.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_jButtonBackActionPerformed

    private void jButtonApplyActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonApplyActionPerformed
        
    java.sql.Connection connection = MySQLConnection();
        
        if(jRadioButtonAdd.isSelected()==true){
            
        MySQLTableAdd(connection);
            
        JFrame jFrame = new JFrame();
        JOptionPane.showMessageDialog(jFrame, "Employee is Added.");
        }else if(jRadioButtonRemove.isSelected()==true){
            
        MySQLTableRemove(connection);
        
        JFrame jFrame = new JFrame();
        JOptionPane.showMessageDialog(jFrame, "Employee is Removed.");
        }else{
            
        }
        
    }//GEN-LAST:event_jButtonApplyActionPerformed

    
    public java.sql.Connection MySQLConnection() {

        java.sql.Connection connection = null;
        String url = "jdbc:mysql://localhost:3306/rms";
        String username = "root";
        String password = "kthrilla1";
        
       
        if (url.length() == 0) {
            System.out.println("Error: Please provide a ConnectionString!");
        } else if (username.length() == 0) {
            System.out.println("Error: Please provide a Username!");
        } else if (password.length() == 0) {
            System.out.println("Error: Please provide a Password!");
        } else {
            System.out.println("Connecting to the database...");

            try {
                       
                url = "jdbc:mysql://localhost:3306/rms";
                username = "root";

                connection = java.sql.DriverManager.getConnection(url, username, password);
                System.out.println("Note: Database connected!");
            } catch (java.sql.SQLException e) {
                System.out.println("Error: Failed to connect to the database!");
                System.out.println(e.toString());
               
            }
        }
        return(connection);
    }
    
    
    public boolean MySQLTableAdd(java.sql.Connection connection){
        
        boolean results = true;
        

        int employeeID = Integer.valueOf(this.jTextFieldEmployeeID.getText());
        String firstName = this.jTextFieldFirstName.getText();
        String lastName = this.jTextFieldLastName.getText();
       // double hours = Double.valueOf(this.jTextFieldDate.getText());
       String hireDate = this.jTextFieldDate.getText();
        
        try{

        
        PreparedStatement posted = connection.prepareStatement("INSERT INTO employee (employeeID,firstName,LastName,hours,hireDate) VALUES ('"+employeeID+"'"+",'"+firstName+"','"+lastName+"','"+0.0+"','"+hireDate+"')");
        posted.executeUpdate();    
        
               
                System.out.println( "Insert Completed.");
                
                return(results);
        }catch (java.sql.SQLException e) {
            System.out.println(e.toString());
        } 
        return(results);
    }
    
    public boolean MySQLTableRemove(java.sql.Connection connection){
        
        boolean results = true;
        

        int employeeID = Integer.valueOf(this.jTextFieldEmployeeID.getText());
        String firstName = this.jTextFieldFirstName.getText();
        String lastName = this.jTextFieldLastName.getText();
      //  double hours = Double.valueOf(this.jTextFieldDate.getText());
       String hireDate = this.jTextFieldDate.getText();
        
        try{

        
        PreparedStatement posted = connection.prepareStatement("DELETE FROM employee WHERE employeeID='"+employeeID+"'");
        posted.executeUpdate();    
        
               
                System.out.println( "Delete Completed.");
                
                return(results);
        }catch (java.sql.SQLException e) {
            System.out.println(e.toString());
        } 
        return(results);
    }
    
    private void jRadioButtonAddStateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_jRadioButtonAddStateChanged

    }//GEN-LAST:event_jRadioButtonAddStateChanged

    private void jRadioButtonAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jRadioButtonAddActionPerformed

    }//GEN-LAST:event_jRadioButtonAddActionPerformed

   
   
        
    
    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(AddRemoveEmployeeJFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(AddRemoveEmployeeJFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(AddRemoveEmployeeJFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(AddRemoveEmployeeJFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new AddRemoveEmployeeJFrame().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JButton jButtonApply;
    private javax.swing.JButton jButtonBack;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JRadioButton jRadioButtonAdd;
    private javax.swing.JRadioButton jRadioButtonRemove;
    private javax.swing.JTextField jTextFieldDate;
    private javax.swing.JTextField jTextFieldEmployeeID;
    private javax.swing.JTextField jTextFieldFirstName;
    private javax.swing.JTextField jTextFieldLastName;
    // End of variables declaration//GEN-END:variables
}
