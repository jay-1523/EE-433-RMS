package EE433;


public class RMS_Sys {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

    //    MySQLConnection();
        ManagerDemo();

//        System.out.println("args.length: " + args.length);
//        for (int index = 0; index < args.length; index++) {
//            System.out.println("args[ " + index + " ]:" + args[index]);
//        }
//
//        if ((args.length == 1) && ((args[0].equalsIgnoreCase("/?") == true) || (args[0].equalsIgnoreCase("/h") == true))) {
//            help(); // explicit call for help
//        } else if ((args.length == 1) && (args[0].equalsIgnoreCase("/ManagerDemo") == true)) {
//            MySQLConnection();
//            ManagerDemo(); // calls staticDemo function   
////        } else if ((args.length == 1) && (args[0].equalsIgnoreCase("/CourseCreationDemo") == true)) {
////            CourseCreationDemo(); // calls staticDemo function   
////        } else if ((args.length == 1) && (args[0].equalsIgnoreCase("/UserCreationDemo") == true)) {
////            UserCreationDemo(); // calls staticDemo function           
//        } else {
//            help(); // implicit call for help  
//        }

    }

    public static void ManagerDemo() {
       
        EE433.ManagerStartJFrame popupManagerStartJFrame = new EE433.ManagerStartJFrame();
        popupManagerStartJFrame.setVisible(true);
//        EE433.Employee sampleEmployee = new EE433.Employee("1","Joe", "Bob");
//        EE433.AddRemoveEmployeeJFrame sampleAddRemoveEmployeeJFrame = new EE433.AddRemoveEmployeeJFrame();
//        //       sampleAddRemoveEmployeeJFrame.getPanel().updateFields(sampleEmployee);
//        sampleAddRemoveEmployeeJFrame.setVisible(true);

    }

    public static void help() {
        System.out.println("Usage");
        System.out.println("    /h or /?        calls help");
        System.out.println("    /ManagerDemo    example Manager UI");
        System.out.println("    /Demo  create courses");
        System.out.println("    /Demo    create students");

    }

    // separate the functions of the SQL into 
    // runheadless() function with tcp connection
    public java.sql.Connection MySQLConnection() {

        java.sql.Connection connection = null;
        // String url = "jdbc:mysql://localhost:3306/rms";
        String url = "jdbc:mysql://localhost:3306/rms";
        String username = "root";
        String password = "kthrilla1";
        
       
        if (url.length() == 0) {
            System.out.println("Error: Please provide a ConnectionString!");
        } else if (username.length() == 0) {
            System.out.println("Error: Please provide a Username!");
        } else if (password.length() == 0) {
            System.out.println("Error: Please provide a Password!");
        } else {
            System.out.println("Connecting to the database...");

            try {
                // things to check...
                // connection is null 
                // connection.isClosed()          
                url = "jdbc:mysql://localhost:3306/rms";
                username = "root";

                connection = java.sql.DriverManager.getConnection(url, username, password);
                System.out.println("Note: Database connected!");
            } catch (java.sql.SQLException e) {
                System.out.println("Error: Failed to connect to the database!");
                System.out.println(e.toString());
                // throw new IllegalStateException("Cannot connect the database!", e);

            }
        }
        return(connection);
    }


}
