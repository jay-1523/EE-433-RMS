/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package RMS.server;

/**
 *
 * @author gmyers
 */
public class Order extends RMS.Order {
    // No UI knowlesge...
    
    private String drink;
    private String sandwich;
    private String side;
    private String dessert;
    
    
    public String ToSQLInsert() {
        String results = "";
        
        // results = ... build your SQL statement...
                
        return (results);
    }
    
    public String ToSQLUpdate() {
        String results = "";
        
        return( results );
    }
    
    // import
    public static RMS.Order FromSQL( Integer ID ) {
        RMS.Order results = new RMS.Order();
                
        return ( results );
    }
    
    // import
    public static RMS.Order FromSQL( Integer ID, String drink, String sandwich, String side, String dessert ) {
     
        return ( null );
    }
    
    // import
    public static RMS.Order FromSQL( java.util.Vector<java.util.Vector<Object>> data ) {
        
        return ( null );
    }
    
    public static RMS.Order FromWaitClient( String text ) {
        // parse the text from the client based on (for example) a colon
                
        return ( null );
    }
    
    public String ToWaitClient( ) {
        String results = "";
        
        results += "drink: " + this.drink + '\n';
        
        
        return ( results );
    }    
    
}
