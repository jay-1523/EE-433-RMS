
package EE433;


public class ManagerStartJFrame extends javax.swing.JFrame {

    
    // Reading table---------------------
    private javax.swing.table.DefaultTableModel buildTableModel(java.sql.ResultSet resultset)
    throws java.sql.SQLException {

        java.sql.ResultSetMetaData resultsetmetaData = resultset.getMetaData();
        java.util.Vector<String> columnNames = new java.util.Vector<String>();
        java.util.Vector<java.util.Vector<Object>> data = new java.util.Vector<java.util.Vector<Object>>();
        
        // names of columns        
        int columnCount = resultsetmetaData.getColumnCount();
        for (int columnindex = 1; columnindex <= columnCount; columnindex++) {
            columnNames.add(resultsetmetaData.getColumnName(columnindex));
        }

        // data of the table
        resultset.beforeFirst();
        while (resultset.next() == true) {
            java.util.Vector<Object> vector = new java.util.Vector<Object>();
            for (int columnindex = 1; columnindex <= columnCount; columnindex++) {
                vector.add(resultset.getObject(columnindex));
            }
            data.add(vector);
        }

        return new javax.swing.table.DefaultTableModel(data, columnNames);
    }
    
    //---------------------------------------------------------------
  
    public ManagerStartJFrame() {
        initComponents();
    }

    
    
  
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jButtonReports = new javax.swing.JButton();
        jButtonAddRemove = new javax.swing.JButton();
        jButtonEmployeeSchedule = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jButtonCurrentEmployeeView = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        jButtonReports.setText("Reports");
        jButtonReports.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonReportsActionPerformed(evt);
            }
        });

        jButtonAddRemove.setText("Add/Remove Employee");
        jButtonAddRemove.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonAddRemoveActionPerformed(evt);
            }
        });

        jButtonEmployeeSchedule.setText("Employee Schedule");
        jButtonEmployeeSchedule.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonEmployeeScheduleActionPerformed(evt);
            }
        });

        jLabel1.setText("Manager Main Page");

        jButtonCurrentEmployeeView.setText("Current Employee View");
        jButtonCurrentEmployeeView.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonCurrentEmployeeViewActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jButtonCurrentEmployeeView, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jButtonEmployeeSchedule, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jButtonReports, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jButtonAddRemove, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(153, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addGap(149, 149, 149))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(42, 42, 42)
                .addComponent(jLabel1)
                .addGap(35, 35, 35)
                .addComponent(jButtonReports, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jButtonEmployeeSchedule, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jButtonCurrentEmployeeView, javax.swing.GroupLayout.DEFAULT_SIZE, 32, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jButtonAddRemove, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(35, 35, 35))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButtonReportsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonReportsActionPerformed
        EE433.ManagerReportOptionsJFrame popupManagerJFrame = new EE433.ManagerReportOptionsJFrame();
        popupManagerJFrame.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_jButtonReportsActionPerformed

    private void jButtonAddRemoveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonAddRemoveActionPerformed
        EE433.AddRemoveEmployeeJFrame popupAddRemoveEmployeeJFrame = new EE433.AddRemoveEmployeeJFrame();
        popupAddRemoveEmployeeJFrame.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_jButtonAddRemoveActionPerformed

    private void jButtonEmployeeScheduleActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonEmployeeScheduleActionPerformed
        EE433.EmployeeScheduleJFrame popupEmployeeScheduleJFrame = new EE433.EmployeeScheduleJFrame();
        popupEmployeeScheduleJFrame.setVisible(true);
        this.setVisible(false);
        popupEmployeeScheduleJFrame.importTableFromMySQL();
        
    }//GEN-LAST:event_jButtonEmployeeScheduleActionPerformed

    private void jButtonCurrentEmployeeViewActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonCurrentEmployeeViewActionPerformed
        EE433.CurrentEmployeeViewJFrame popupCurrentEmployeeViewJFrame = new EE433.CurrentEmployeeViewJFrame();
        popupCurrentEmployeeViewJFrame.setVisible(true);
        this.setVisible(false);
        popupCurrentEmployeeViewJFrame.importTableFromMySQL();
        
        
        
    }//GEN-LAST:event_jButtonCurrentEmployeeViewActionPerformed

    
    public void getSQLResults(String MySQLStatement){
        java.sql.Statement statement = null;
        java.sql.ResultSet resultset = null;
        java.sql.ResultSetMetaData resultsetmetadata = null;
        java.lang.Boolean success = false;
        
        java.sql.Connection connection = null;
       // connection = java.sql.DriverManager.getConnection(url, username, password);

        try {
            if ( MySQLStatement.length() == 0 ) {
                System.out.println("Error: No command provided!");
//            } else if ( connection == null ) {
//                System.out.println("Error: Not connected to the database.  Please reconnect.");
//            } else if ( connection.isClosed() ) {
//                System.out.println("Error: Not connected to the database.  Please reconnect.");
            } else {
                               
                statement = connection.createStatement( java.sql.ResultSet.TYPE_SCROLL_INSENSITIVE, DISPOSE_ON_CLOSE);
                System.out.println( statement.toString()); // likely comment out later...
                
                success = statement.execute( MySQLStatement );                
                System.out.println( statement.toString()); // likely comment out later...
                
                if ( success == true ) {
                    resultset = statement.getResultSet();
                    System.out.println( resultset.toString()); // definitely comment out later...
                    
                    resultsetmetadata = resultset.getMetaData();
                    System.out.println( "ColumnCount: " + resultsetmetadata.getColumnCount() );
                    
                    // display columns
                    for (int columnindex = 1; columnindex <= resultsetmetadata.getColumnCount(); columnindex++ ) {
                        System.out.println("ColumnIndex: " + columnindex + "; ColumnName: " + resultsetmetadata.getColumnName(columnindex ));
                    }
                    
                    while (resultset.next() == true) {                        
                        for (int columnindex = 1; columnindex < resultsetmetadata.getColumnCount(); columnindex++ ) {
                            // System.out.println("Cell (" + resultset.getRow() + ", columnindex): " + resultset.getNString( columnindex ) );
                            System.out.println("Cell (" + resultset.getRow() + ", index): " + resultset.getString(columnindex) );
                        }
                    }
                    
                //    this.jTableResults.setModel( this.buildTableModel( resultset ));
                } else {
                    System.out.println("Warning: Nothing was accomplished.  Verify that you expect this.");                    
                }
            }
        } catch (java.sql.SQLException e) {
            System.out.println(e.toString());
        }                    
    }
    
    
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ManagerStartJFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ManagerStartJFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ManagerStartJFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ManagerStartJFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ManagerStartJFrame().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButtonAddRemove;
    private javax.swing.JButton jButtonCurrentEmployeeView;
    private javax.swing.JButton jButtonEmployeeSchedule;
    private javax.swing.JButton jButtonReports;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    // End of variables declaration//GEN-END:variables
}
