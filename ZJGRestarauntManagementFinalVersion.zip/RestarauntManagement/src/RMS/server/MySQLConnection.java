/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package RMS.server;

import static javax.swing.WindowConstants.DISPOSE_ON_CLOSE;

/**
 *
 * @author zgriffin
 */
public class MySQLConnection {
//        // String url = "jdbc:mysql://localhost:3306/ee433";

    String url = "";
    String username = "";
    String password = "";
    private java.sql.Connection connection = null;
    java.sql.ResultSet resultSet = null;

    public MySQLConnection(String url, String username, String password) {
        this.url = url;
        this.username = username;
        this.password = password;
//        java.sql.Connection connection = new java.sql.Connection(); // abstract
//        
        if (this.url.length() == 0) {
            System.out.println("Error: Please provide a ConnectionString!");
        } else if (this.username.length() == 0) {
            System.out.println("Error: Please provide a Username!");
        } else if (this.password.length() == 0) {
            System.out.println("Error: Please provide a Password!");
        } else {
            System.out.println("Connecting to the database...");

            try {
                // things to check...
                // connection is null 
                // connection.isClosed()          
//                url = this.jTextConnectionString.getText();
//                username = this.jTextUsername.getText();
                // password = this.jPassword.getPassword(); // won't work!!!

                // connection = java.sql.DriverManager.getConnection(url, username, password);
                // System.out.println(new String(this.jPassword.getPassword()));
                connection = java.sql.DriverManager.getConnection(this.url, this.username, new String(this.password));
                System.out.println("Note: Database connected!");
                System.out.println(connection.toString());
            } catch (java.sql.SQLException e) {
                System.out.println("Error: Failed to connect to the database!");
                System.out.println(e.toString());
                // throw new IllegalStateException("Cannot connect the database!", e);
            }
        }
    }

    public java.sql.ResultSet MySQLCommand(String textCommand) {
        // TODO add your handling code here:
        java.sql.Statement statement = null;
        java.sql.ResultSet resultset = null;
        java.sql.ResultSetMetaData resultsetmetadata = null;
        java.lang.Boolean success = false;

        try {
            if (textCommand.length() == 0) {
                System.out.println("Error: No command provided!");
            } else if (connection == null) {
                System.out.println("Error: Not connected to the database.  Please reconnect.");
            } else if (connection.isClosed()) {
                System.out.println("Error: Not connected to the database.  Please reconnect.");
            } else {
                // statement = connection.createStatement();                
                statement = connection.createStatement(java.sql.ResultSet.TYPE_SCROLL_INSENSITIVE, DISPOSE_ON_CLOSE);
                System.out.println(statement.toString()); // likely comment out later...

                success = statement.execute(textCommand);
                //System.out.println( statement.toString()); // likely comment out later...

                if (success == true) {
                    resultset = statement.getResultSet();
                    this.resultSet = resultset;
                    //System.out.println( resultset.toString()); // definitely comment out later...

                    // resultsetmetadata = resultset.getMetaData();
                    // System.out.println( "ColumnCount: " + resultsetmetadata.getColumnCount() );
                    // display columns
                    // for (int columnindex = 1; columnindex <= resultsetmetadata.getColumnCount(); columnindex++ ) {
                    //     System.out.println("ColumnIndex: " + columnindex + "; ColumnName: " + resultsetmetadata.getColumnName(columnindex ));
                    // }
                    //  while (resultset.next() == true) {                        
                    //   for (int columnindex = 1; columnindex < resultsetmetadata.getColumnCount(); columnindex++ ) {
                    // System.out.println("Cell (" + resultset.getRow() + ", columnindex): " + resultset.getNString( columnindex ) );
                    //      System.out.println("Cell (" + resultset.getRow() + ", index): " + resultset.getString(columnindex) );
                    // }
                    // }                    
                    // this.jTableResults.setModel( this.buildTableModel( resultset ));
                } else {
                    System.out.println("Warning: Nothing was accomplished.  Verify that you expect this.");
                }
            }
        } catch (java.sql.SQLException e) {
            System.out.println(e.toString());
        }
        return (resultset);
    }

    public String SQLToMenu(java.sql.Connection connection, String menuType) {
        this.connection = connection;
        java.sql.ResultSet resultset = null;
        java.sql.ResultSetMetaData resultsetmetadata = null;
        String menu = "";

        resultset = MySQLCommand("SELECT * FROM " + menuType + ";");

        //System.out.println(resultset.toString());
        try {
            if (resultset == null) {
                System.out.println("no restults");
            } else {
                resultsetmetadata = resultset.getMetaData();

                while (resultset.next() == true) {
                    menu += resultset.getString(2) + ";";
                }
            }
        } catch (java.sql.SQLException e) {
            System.out.println(e.toString());
        }

        return (menu);

    }

    /**
     * @return the connection
     */
    public java.sql.Connection getConnection() {
        return connection;
    }

}
