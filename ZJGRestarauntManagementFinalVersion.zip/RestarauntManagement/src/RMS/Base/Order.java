/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package RMS.Base;

/**
 *
 * @author zgriffin
 */
public class Order {
    public Integer ID; //TBD

    /**
     * @return the ID
     */
    public Integer getID() {
        return ID;
    }

//    /**
//     * @param ID the ID to set
//     */
//    public void setID(Integer ID) {
//        this.ID = ID;
//    }
    

}
