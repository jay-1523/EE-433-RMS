
package EE433;

//import java.sql.PreparedStatement;
//import java.sql.ResultSet;
//import javax.swing.JOptionPane;

import java.util.Enumeration;
import java.util.HashSet;
import java.util.Set;
import javax.swing.ListSelectionModel;
import javax.swing.event.TableColumnModelListener;
import javax.swing.table.TableColumn;

public class ManagerReportJFrame extends javax.swing.JFrame {

  
    public ManagerReportJFrame() {
        initComponents();
    }

    
    private javax.swing.table.DefaultTableModel buildTableModel(java.sql.ResultSet resultset)
            throws java.sql.SQLException {

        java.sql.ResultSetMetaData resultsetmetaData = resultset.getMetaData();
        java.util.Vector<String> columnNames = new java.util.Vector<String>();
        java.util.Vector<java.util.Vector<Object>> data = new java.util.Vector<java.util.Vector<Object>>();
        
        // names of columns        
        int columnCount = resultsetmetaData.getColumnCount();
        for (int columnindex = 1; columnindex <= columnCount; columnindex++) {
            columnNames.add(resultsetmetaData.getColumnName(columnindex));
        }

        // data of the table
        resultset.beforeFirst();
        while (resultset.next() == true) {
            java.util.Vector<Object> vector = new java.util.Vector<Object>();
            for (int columnindex = 1; columnindex <= columnCount; columnindex++) {
                vector.add(resultset.getObject(columnindex));
            }
            data.add(vector);
        }

        return new javax.swing.table.DefaultTableModel(data, columnNames);

     }
    
    
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jButtonBack = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        textArea1 = new java.awt.TextArea();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTableResults = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        jButtonBack.setText("Back to Reports");
        jButtonBack.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonBackActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jButtonBack, javax.swing.GroupLayout.PREFERRED_SIZE, 134, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(652, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jButtonBack, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        jPanel2.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        textArea1.setEditable(false);

        jTableResults.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(jTableResults);

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(textArea1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jScrollPane1)
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addComponent(textArea1, javax.swing.GroupLayout.PREFERRED_SIZE, 287, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(24, 24, 24)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 263, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButtonBackActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonBackActionPerformed
       
        EE433.ManagerReportOptionsJFrame popupManagerJFrame = new EE433.ManagerReportOptionsJFrame();
        popupManagerJFrame.setVisible(true);
        this.setVisible(false);
        
        
    }//GEN-LAST:event_jButtonBackActionPerformed

    
   
      public boolean importTableFromMySQL(){
        
        java.sql.Connection connection = MySQLConnection();
        
        boolean results = true;
        
        java.sql.Statement statement = null;
        java.sql.ResultSet resultset = null;
        java.sql.ResultSetMetaData resultsetmetadata = null;
        java.lang.Boolean success = false;
        
        String sqlStatment = "SELECT * FROM rms.sales";

        try {
            if ( connection == null ) {
                System.out.println("Error: Not connected to the database.  Please reconnect.");
            } else if ( connection.isClosed() ) {
                System.out.println("Error: Not connected to the database.  Please reconnect.");
            } else {
                    
                statement = connection.createStatement( java.sql.ResultSet.TYPE_SCROLL_INSENSITIVE, DISPOSE_ON_CLOSE);
                System.out.println( statement.toString()); // likely comment out later...
                
                success = statement.execute(sqlStatment);                
                System.out.println( statement.toString()); // likely comment out later...
                
                if ( success == true ) {
                    resultset = statement.getResultSet();
                    System.out.println( resultset.toString()); // definitely comment out later...
                    
                    resultsetmetadata = resultset.getMetaData();
                    System.out.println( "ColumnCount: " + resultsetmetadata.getColumnCount() );
                    
                    // display columns
                    for (int columnindex = 1; columnindex <= resultsetmetadata.getColumnCount(); columnindex++ ) {
                        System.out.println("ColumnIndex: " + columnindex + "; ColumnName: " + resultsetmetadata.getColumnName(columnindex ));
                    }
                    
                    while (resultset.next() == true) {                        
                        for (int columnindex = 1; columnindex < resultsetmetadata.getColumnCount(); columnindex++ ) {
                            // System.out.println("Cell (" + resultset.getRow() + ", columnindex): " + resultset.getNString( columnindex ) );
                            System.out.println("Cell (" + resultset.getRow() + ", index): " + resultset.getString(columnindex) );
                        }
                    }
                    
                    this.jTableResults.setModel( this.buildTableModel( resultset ));
                } else {
                    System.out.println("Warning: Nothing was accomplished.  Verify that you expect this.");                    
                }
            }
        } catch (java.sql.SQLException e) {
            System.out.println(e.toString());
        } 
        
        return(results);
    }
    
    
    
    
    
    
//    ResultSet rs = null;
//    PreparedStatement ps = null;
//    
//    public ResultSet find(String s){
//        try{
//            ps = connection.prepareStatement("SELECT * from sales WHERE salesID = ?");
//            rs = ps.executeQuery();
//        }catch(java.sql.SQLException ex){
//            JOptionPane.showMessageDialog(null,ex.getMessage());
//            
//        }
//        return rs;
//    }
    
    
    
    
    
    
     public java.sql.Connection MySQLConnection() {

        java.sql.Connection connection = null;
        String url = "jdbc:mysql://localhost:3306/rms";
        String username = "root";
        String password = "kthrilla1";
        
       
        if (url.length() == 0) {
            System.out.println("Error: Please provide a ConnectionString!");
        } else if (username.length() == 0) {
            System.out.println("Error: Please provide a Username!");
        } else if (password.length() == 0) {
            System.out.println("Error: Please provide a Password!");
        } else {
            System.out.println("Connecting to the database...");

            try {
                       
                url = "jdbc:mysql://localhost:3306/rms";
                username = "root";

                connection = java.sql.DriverManager.getConnection(url, username, password);
                System.out.println("Note: Database connected!");
            } catch (java.sql.SQLException e) {
                System.out.println("Error: Failed to connect to the database!");
                System.out.println(e.toString());
               
            }
        }
        return(connection);
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ManagerReportJFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ManagerReportJFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ManagerReportJFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ManagerReportJFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ManagerReportJFrame().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButtonBack;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTableResults;
    private java.awt.TextArea textArea1;
    // End of variables declaration//GEN-END:variables
}
