/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package EE433;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

/**
 *
 * @author Josh Yates
 */
public class RestrauntManagementSystem_Ex {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Connection conn = null; //This is initial connection
        
        try {
            Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/employees?" +
                                           "user=root&password=Football12");
            if(!conn.isClosed()) //If false, then we are successfully connected
            {
                System.out.println("Database connected");
            }
            else
            {
                System.out.println("Database unable to connect");
            }
            //Once connected to the DB - Retreive the employees with a query
            String query = "select * from employees";
            PreparedStatement ps = conn.prepareStatement(query);
            ResultSet rs = ps.executeQuery(); //execute the query and return results in result set
            while(rs.next()) //iterate through resultSet to get all results
            {
                String id = rs.getString("idemployees");
                String name = rs.getString("name");
                String tier = rs.getString("tier");
                System.out.println("Employee id = " + id + " and name = " + name + " and tier = " + tier);
            }
            
            System.out.println("All Employees have been queried. ");

        } catch (SQLException ex) {
            // handle any errors
            System.out.println("SQLException: " + ex.getMessage());
            System.out.println("SQLState: " + ex.getSQLState());
            System.out.println("VendorError: " + ex.getErrorCode());
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Login_Frame.class.getName()).log(Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            Logger.getLogger(Login_Frame.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            Logger.getLogger(Login_Frame.class.getName()).log(Level.SEVERE, null, ex);
        }
    

        new Login_Frame().setVisible(true);
    }
    
}
