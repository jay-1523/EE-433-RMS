
package RMS;

/**
 *
 * @author gmyers
 */
public class Order {
    private Integer ID; // TBD

    /**
     * @return the ID
     */
    public Integer getID() {
        return ID;
    }

    /**
     * @param ID the ID to set
     */
//    public void setID(Integer ID) {
//        this.ID = ID;
//    }
    
    // meta data...
    // StartTime
    // EndTime
    
}
