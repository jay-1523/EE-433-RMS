/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package EE433;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;




/**
 *
 * @author roman
 */
public class TCPClientRMS {
    
    public static void main(String [] args) {
      
      
      String serverName = "173.31.130.210"; 
      
      
      int port = Integer.parseInt("1434");
      
      try {
          
         System.out.println("Connecting to " + serverName + " on port " + port);
          
         Socket client = new Socket(serverName, port);
       
         System.out.println("Just connected to " + client.getRemoteSocketAddress());
          
         OutputStream outToServer = client.getOutputStream();
         DataOutputStream out = new DataOutputStream(outToServer);
         
         
         out.writeUTF("Connecting from " + client.getLocalSocketAddress());
         InputStream inFromServer = client.getInputStream();
         DataInputStream in = new DataInputStream(inFromServer);
         
         System.out.println("Server says " + in.readUTF());
         
       //  client.close();
          
      } catch (IOException e) {
         e.printStackTrace();
      }
    
    }
   }
    

