
package EE433;

import java.sql.PreparedStatement;
import java.util.Enumeration;
import java.util.HashSet;
import java.util.Set;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.ListSelectionModel;
import javax.swing.event.TableColumnModelListener;
import javax.swing.table.TableColumn;


public class EmployeeScheduleJFrame extends javax.swing.JFrame {
    
    //java.sql.Connection connection = null;

    private javax.swing.table.DefaultTableModel buildTableModel(java.sql.ResultSet resultset)
    
    throws java.sql.SQLException {

        java.sql.ResultSetMetaData resultsetmetaData = resultset.getMetaData();
        java.util.Vector<String> columnNames = new java.util.Vector<String>();
        java.util.Vector<java.util.Vector<Object>> data = new java.util.Vector<java.util.Vector<Object>>();

        // names of columns        
        int columnCount = resultsetmetaData.getColumnCount();
        for (int columnindex = 1; columnindex <= columnCount; columnindex++) {
            columnNames.add(resultsetmetaData.getColumnName(columnindex));
        }

        // data of the table
        resultset.beforeFirst();
        while (resultset.next() == true) {
            java.util.Vector<Object> vector = new java.util.Vector<Object>();
            for (int columnindex = 1; columnindex <= columnCount; columnindex++) {
                vector.add(resultset.getObject(columnindex));
            }
            data.add(vector);
        }

        return new javax.swing.table.DefaultTableModel(data, columnNames);

    }
    
    
   
    public EmployeeScheduleJFrame() {
        initComponents();
        updateDropdownRole();
        updateDropdownEmployeeID();
        updateDropdownScheduleID();
    }

    
    public boolean updateDropdownRole(){
        
        boolean results = true;
        
        java.io.File InputFile;
        java.io.FileReader InputFileReader;
        java.io.BufferedReader InputBufferedReader;
        String line = "";

        this.jComboBox2.removeAllItems();

        try {
            InputFile = new java.io.File("Role.txt");
            if (InputFile.exists() == true) {
                InputFileReader = new java.io.FileReader(InputFile);
                InputBufferedReader = new java.io.BufferedReader(InputFileReader);

                while ((line = InputBufferedReader.readLine()) != null) {
                    this.jComboBox2.addItem(line);
                   
                }
                InputBufferedReader.close();
            } else {
                System.out.println("Error: No Role.txt provided!");
            }
        } catch (java.lang.Exception ex) {
            System.out.println(ex.toString());
        }
        return(results);

}
    
    public boolean updateDropdownEmployeeID(){
        
        boolean results = true;
        
        java.io.File InputFile;
        java.io.FileReader InputFileReader;
        java.io.BufferedReader InputBufferedReader;
        String line = "";

        this.jComboBox1.removeAllItems();

        try {
            InputFile = new java.io.File("EmployeeID.txt");
            if (InputFile.exists() == true) {
                InputFileReader = new java.io.FileReader(InputFile);
                InputBufferedReader = new java.io.BufferedReader(InputFileReader);

                while ((line = InputBufferedReader.readLine()) != null) {
                    this.jComboBox1.addItem(line);
                   
                }
                InputBufferedReader.close();
            } else {
                System.out.println("Error: No EmployeeID.txt provided!");
            }
        } catch (java.lang.Exception ex) {
            System.out.println(ex.toString());
        }
        return(results);

}
    
     public boolean updateDropdownScheduleID(){
        
        boolean results = true;
        
        java.io.File InputFile;
        java.io.FileReader InputFileReader;
        java.io.BufferedReader InputBufferedReader;
        String line = "";

        this.jComboBoxScheduleID.removeAllItems();

        try {
            InputFile = new java.io.File("ScheduleID.txt");
            if (InputFile.exists() == true) {
                InputFileReader = new java.io.FileReader(InputFile);
                InputBufferedReader = new java.io.BufferedReader(InputFileReader);

                while ((line = InputBufferedReader.readLine()) != null) {
                    this.jComboBoxScheduleID.addItem(line);
                   
                }
                InputBufferedReader.close();
            } else {
                System.out.println("Error: No ScheduleID.txt provided!");
            }
        } catch (java.lang.Exception ex) {
            System.out.println(ex.toString());
        }
        return(results);

}
    
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        jPanel1 = new javax.swing.JPanel();
        jButtonApply = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTableResults = new javax.swing.JTable();
        jComboBox1 = new javax.swing.JComboBox<>();
        jComboBox2 = new javax.swing.JComboBox<>();
        jTextField1 = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jRadioButtonAdd = new javax.swing.JRadioButton();
        jRadioButtonRemove = new javax.swing.JRadioButton();
        jButtonBack = new javax.swing.JButton();
        jButtonEmployeeView = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        jComboBoxScheduleID = new javax.swing.JComboBox<>();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        jButtonApply.setText("Apply");
        jButtonApply.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonApplyActionPerformed(evt);
            }
        });

        jTableResults.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(jTableResults);

        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        jComboBox2.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        jTextField1.setText("2021-12-9 10:27:00");

        jLabel1.setText("Employee ID:");

        jLabel2.setText("Role:");

        jLabel3.setText("Date:");

        buttonGroup1.add(jRadioButtonAdd);
        jRadioButtonAdd.setText("Add");

        buttonGroup1.add(jRadioButtonRemove);
        jRadioButtonRemove.setText("Remove");

        jButtonBack.setText("Back to Main Page");
        jButtonBack.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonBackActionPerformed(evt);
            }
        });

        jButtonEmployeeView.setText("Current Employee View");
        jButtonEmployeeView.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonEmployeeViewActionPerformed(evt);
            }
        });

        jLabel4.setText("Schedule ID:");

        jComboBoxScheduleID.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(31, 31, 31)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jButtonApply, javax.swing.GroupLayout.PREFERRED_SIZE, 115, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel1)
                            .addComponent(jLabel2)
                            .addComponent(jLabel3)
                            .addComponent(jLabel4))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 48, Short.MAX_VALUE)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jRadioButtonAdd)
                                .addGap(18, 18, 18)
                                .addComponent(jRadioButtonRemove))
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(jComboBox2, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jComboBox1, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jTextField1, javax.swing.GroupLayout.DEFAULT_SIZE, 137, Short.MAX_VALUE)
                                .addComponent(jComboBoxScheduleID, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))))
                .addGap(353, 353, 353))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jButtonBack)
                        .addGap(18, 18, 18)
                        .addComponent(jButtonEmployeeView, javax.swing.GroupLayout.PREFERRED_SIZE, 204, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jRadioButtonAdd)
                    .addComponent(jRadioButtonRemove))
                .addGap(9, 9, 9)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(jComboBoxScheduleID, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(6, 6, 6)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(3, 3, 3)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(13, 13, 13)
                        .addComponent(jLabel2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel3)
                        .addGap(32, 32, 32)
                        .addComponent(jButtonApply))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(11, 11, 11)
                        .addComponent(jComboBox2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 290, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 13, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jButtonBack, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jButtonEmployeeView))
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButtonBackActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonBackActionPerformed
        EE433.ManagerStartJFrame popupManagerStartJFrame = new EE433.ManagerStartJFrame();
        popupManagerStartJFrame.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_jButtonBackActionPerformed

    private void jButtonEmployeeViewActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonEmployeeViewActionPerformed
        EE433.CurrentEmployeeViewJFrame popupCurrentEmployeeViewJFrame = new EE433.CurrentEmployeeViewJFrame();
        popupCurrentEmployeeViewJFrame.setVisible(true);
        this.setVisible(false);
        
        popupCurrentEmployeeViewJFrame.importTableFromMySQL();
        
    }//GEN-LAST:event_jButtonEmployeeViewActionPerformed

    private void jButtonApplyActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonApplyActionPerformed

        java.sql.Connection connection = MySQLConnection();
        
        if(jRadioButtonAdd.isSelected()==true){
            
        
        MySQLTableAdd(connection);   
        
        importTableFromMySQL();
        
        }else if(jRadioButtonRemove.isSelected()==true){
            
        MySQLTableRemove(connection);
        
        importTableFromMySQL();
        }else{
            
        }
        
    }//GEN-LAST:event_jButtonApplyActionPerformed

    public boolean importTableFromMySQL(){
        
        java.sql.Connection connection = MySQLConnection();
        
        boolean results = true;
        
        java.sql.Statement statement = null;
        java.sql.ResultSet resultset = null;
        java.sql.ResultSetMetaData resultsetmetadata = null;
        java.lang.Boolean success = false;
        
        String sqlStatment = "SELECT * FROM rms.schedule";

        try {
            if ( connection == null ) {
                System.out.println("Error: Not connected to the database.  Please reconnect.");
            } else if ( connection.isClosed() ) {
                System.out.println("Error: Not connected to the database.  Please reconnect.");
            } else {
                    
                statement = connection.createStatement( java.sql.ResultSet.TYPE_SCROLL_INSENSITIVE, DISPOSE_ON_CLOSE);
                System.out.println( statement.toString()); // likely comment out later...
                
                success = statement.execute(sqlStatment);                
                System.out.println( statement.toString()); // likely comment out later...
                
                if ( success == true ) {
                    resultset = statement.getResultSet();
                    System.out.println( resultset.toString()); // definitely comment out later...
                    
                    resultsetmetadata = resultset.getMetaData();
                    System.out.println( "ColumnCount: " + resultsetmetadata.getColumnCount() );
                    
                    // display columns
                    for (int columnindex = 1; columnindex <= resultsetmetadata.getColumnCount(); columnindex++ ) {
                        System.out.println("ColumnIndex: " + columnindex + "; ColumnName: " + resultsetmetadata.getColumnName(columnindex ));
                    }
                    
                    while (resultset.next() == true) {                        
                        for (int columnindex = 1; columnindex < resultsetmetadata.getColumnCount(); columnindex++ ) {
                            // System.out.println("Cell (" + resultset.getRow() + ", columnindex): " + resultset.getNString( columnindex ) );
                            System.out.println("Cell (" + resultset.getRow() + ", index): " + resultset.getString(columnindex) );
                        }
                    }
                    
                    this.jTableResults.setModel( this.buildTableModel( resultset ));
                } else {
                    System.out.println("Warning: Nothing was accomplished.  Verify that you expect this.");                    
                }
            }
        } catch (java.sql.SQLException e) {
            System.out.println(e.toString());
        } 
        
        return(results);
    }
    
    
    public java.sql.Connection MySQLConnection() {

        java.sql.Connection connection = null;
        String url = "jdbc:mysql://localhost:3306/rms";
        String username = "root";
        String password = "kthrilla1";
        
       
        if (url.length() == 0) {
            System.out.println("Error: Please provide a ConnectionString!");
        } else if (username.length() == 0) {
            System.out.println("Error: Please provide a Username!");
        } else if (password.length() == 0) {
            System.out.println("Error: Please provide a Password!");
        } else {
            System.out.println("Connecting to the database...");

            try {
                       
                url = "jdbc:mysql://localhost:3306/rms";
                username = "root";

                connection = java.sql.DriverManager.getConnection(url, username, password);
                System.out.println("Note: Database connected!");
            } catch (java.sql.SQLException e) {
                System.out.println("Error: Failed to connect to the database!");
                System.out.println(e.toString());
               
            }
        }
        return(connection);
    }
    
    public boolean MySQLTableAdd(java.sql.Connection connection){
        
        boolean results = true;
        
        int scheduleID = Integer.valueOf(this.jComboBoxScheduleID.getSelectedItem().toString());
        int employeeID = Integer.valueOf(this.jComboBox1.getSelectedItem().toString());
        String date = this.jTextField1.getText();
        String role = this.jComboBox2.getSelectedItem().toString();
       
        
        try{

        
        PreparedStatement posted = connection.prepareStatement("INSERT INTO schedule (scheduleID,employeeID,role,date) VALUES ('"+scheduleID+"'"+",'"+employeeID+"','"+role+"','"+date+"')");
        posted.executeUpdate();    
        
               
                System.out.println( "Insert Completed.");
                
                return(results);
        }catch (java.sql.SQLException e) {
            System.out.println(e.toString());
        } 
        return(results);
    }
    
    public boolean MySQLTableRemove(java.sql.Connection connection){
        
        boolean results = true;
        

       int scheduleID = Integer.valueOf(this.jComboBoxScheduleID.getSelectedItem().toString());
       
        
        try{

        
        PreparedStatement posted = connection.prepareStatement("DELETE FROM schedule WHERE scheduleID='"+scheduleID+"'");
        posted.executeUpdate();    
        
               
                System.out.println( "Delete Completed.");
                
                return(results);
        }catch (java.sql.SQLException e) {
            System.out.println(e.toString());
        } 
        return(results);
    }

    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(EmployeeScheduleJFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(EmployeeScheduleJFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(EmployeeScheduleJFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(EmployeeScheduleJFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new EmployeeScheduleJFrame().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JButton jButtonApply;
    private javax.swing.JButton jButtonBack;
    private javax.swing.JButton jButtonEmployeeView;
    private javax.swing.JComboBox<String> jComboBox1;
    private javax.swing.JComboBox<String> jComboBox2;
    private javax.swing.JComboBox<String> jComboBoxScheduleID;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JRadioButton jRadioButtonAdd;
    private javax.swing.JRadioButton jRadioButtonRemove;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTableResults;
    private javax.swing.JTextField jTextField1;
    // End of variables declaration//GEN-END:variables
}
