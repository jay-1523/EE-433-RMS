
package RMS.CookClient;

/**
 *
 * @author gmyers
 */
public class Order {
    // NO SQL knowledge
    // No knowledge of price, menu description, etc...
    // probably needs to know about in and out times...
}
